import axios from "axios";
import request from "./base";
import Cookies from "js-cookie";
export const getUsers = (page) => {
  return request({
    url:'/manager/list',
    method:'GET',
  })
}
export const deleteUser = () => {
  return request({
    url:'/user/update',
    method:'PUT',

  })
}
export const ping = () => {
  return request({
    url:'/manager/ping',
    method:'GET',
  })
}