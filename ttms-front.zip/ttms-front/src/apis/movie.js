import request from "./base";
import axios from "axios"
export const addMovie2 = (params) => {
  return axios.post("http://192.168.1.113:9090/api/v1/movie/create",{params})
}
export const addMovie = (params) => {
  return request({
    url:'/movie/create',
    method:'POST',
    data:params
  })
}
export const getAllMovie = () => {
  return request({
    url:'/movie/list',
    method:'GET'
  })
}
export const deleteMovie = (params) => {
  return request({
    url:'/movie',
    method:'DELETE',
    data:params
  })
}
// export const addMovie = (form) => {
//   return request({
//     url:'/movie/create',
//     method:'POST',
//     params:{
//       actors:form.actors,
//       area:form.area,
//       avatar:form.avatar,
//       content:form.content,
//       director:form.director,
//       duration:form.duration,
//       name:form.name,
//       show_time:form.show_time,
//       tags:form.tags
//     }

//   })
// }
export const getMovieDetail = (movieID) => {
  return request({
    url:'/movie/detail',
    method:'POST',
    data:{
      movieID
    }
  })
}
export const getMovieInfoByTag = () => {
  return request({
    url:'/movie/buTagAreaPeriod',
    method:'get',
    
  })
}
export const getMovieByName = (key) => {
  return request({
    url:'/movie/byNameOrContent',
    method:'POST',
    data:{
      key:''
    }
  })
}