service.interceptors.request.use(
  config => {
      // console.log(config);
      // 在请求发送之前做一些处理
      if (store.getters.token) {
          // 让每个请求携带token-- ['X-Token']为自定义key 请根据实际情况自行修改
          config.headers['Authorization'] = getToken();

          // 判断token是否即将过期，且不是请求刷新token的接口
          if (isTokenExpired() && config.url !== '/admin/base/refresh') {
              // 所有的请求来了，先判断是否正在刷新token，
              // 如果不是，将刷新token标志置为true并请求刷新token.
              // 如果是，则先将请求缓存到数组中
              // 等到刷新完token后再次重新请求之前缓存的请求接口即可
              if (!window.isRefreshing) {
                  // 标志改为true，表示正在刷新
                  window.isRefreshing = true;
                  let userInfo = getUserInfo() ? JSON.parse(getUserInfo()) : '';
                  const data = {
                      uuid: userInfo.uuid,
                      expiresAt: Number(getExpires())
                  }
                  refreshToken(data).then(res => {
                      if (res.data.code == 200) {
                          // 更新cookie里的值
                          setToken(res.data.data.token, new Date(res.data.data.expiresAt));
                          setExpires(res.data.data.expiresAt, new Date(res.data.data.expiresAt));
                          setUserInfo(JSON.parse(getUserInfo()), new Date(res.data.data.expiresAt))
                          // 更新 store里的值
                          store.commit('SET_TOKEN', res.data.data.token);
                          store.commit('SET_EXPIRESAT', res.data.data.expiresAt);
                          // 将刷新的token替代老的token
                          config.headers['Authorization'] = getToken();
                          // 刷新token完成后重新请求之前的请求
                          afreshRequest(getToken())
                      } else {
                          Message({
                              message: res.data.msg,
                              type: 'error',
                          })
                          store.dispatch('resetUserCookies').then(() => {
                              location.reload() // 为了重新实例化vue-router对象 避免bug
                          })
                      }
                  }).catch(err => {
                      console.log('refreshToken err =>' + err);
                      store.dispatch('resetUserCookies').then(() => {
                          location.reload() // 为了重新实例化vue-router对象 避免bug
                      })
                  }).finally(() => {
                      window.isRefreshing = false;
                  })
                  // 下面这段代码一定要写，不然第一个请求的接口带过去的token还是原来的，要将第一个请求也缓存起来
                  let retry = new Promise((resolve) => {
                      cacheRequestArrHandle((token) => {
                          config.headers['Authorization'] = token; // token为刷新完成后传入的token
                          // 将请求挂起
                          resolve(config)
                      })
                  })
                  return retry;
              } else {
                  let retry = new Promise((resolve) => {
                      cacheRequestArrHandle((token) => {
                          config.headers['Authorization'] = token; // token为刷新完成后传入的token
                          // 将请求挂起
                          resolve(config)
                      })
                  })
                  return retry;
              }
          } else {
              return config
          }
      }
      return config
  },
  error => {
      // 请求错误处理
      Promise.reject(error)
  }
)

