<template>
  <div class="footer">
    <p class="friendly-links">
      关于magnolai:
      <a href="#">关于我们</a>
      <span></span>
      <a href="#">投资者关系</a>
      &nbsp;&nbsp;&nbsp;&nbsp;友情链接：
      <a href="#">刘sir</a>
      <span></span>
      <a href="#">王sir</a>
      <span></span>
      <a href="#">康sir</a>
      <span></span>
      <a href="#">朱sir</a>
      <span></span>
      <a href="#">挂件</a>
    </p>
    <p class="friendly-links">
      
    商务合作邮箱：haimianbaibai.com
    客服电话：110
    违法和不良信息/涉未成年人有害信息举报电话：110didididididid
  
    </p>
    <p class="friendly-links">
      
    用户举报/涉未成年人有害信息举报邮箱：haimianbaibai@qq.com
    舞弊线索举报邮箱：haimianbaibaiwubi@qq.com
    舞弊线索举报邮箱：haimianbaibaiwubi@qq.com
  
    </p>
    <p class="friendly-links">
      增值业务经营许可证 haimianbaibaiasdasd123123
    </p>
    <p class="friendly-links">
      营业性演出许可证 magnolai(机构)1231412412421324号
    </p>
    <p class="friendly-links">
          商务合作邮箱：haimianbaibai.com
    客服电话：110
    违法和不良信息/涉未成年人有害信息举报电话：110didididididid
    </p>
        <p class="friendly-links">
     增值magnolai经营许可证 haimianbaibaiasdasd123123
    </p>
            <p class="friendly-links">
      magnolai文化传媒有限公司
    </p>
                <p class="friendly-links">
      magnolai www.haimianbaibai.com
    </p>
  </div>
</template>

<script>
export default {
  name: 'Footer'
}
</script>

<style scoped>
  .footer {
    height: 280px;
    background-color: #262426;
    padding: 80px 0;
    margin: 0 auto;
    min-width: 1200px;
    margin-top: 82px;
   width: 99vw;
  }
  .footer p {
    color: #ccc;
    margin: 0;
    padding: 0;
    text-align: center;
    font-size: 14px;
    line-height: 22px;
    height: 22px;
  }
  .friendly-links a {
    color: #ef4238;
    text-decoration: none;
  }
  .friendly-links a:hover {
    text-decoration: underline;
  }
  .friendly-links span {
    display: inline-block;
    border-left: 1px solid #ccc;
    margin: 0 7px;
    height: 12px;
    position: relative;
    top: 1px;
  }
</style>