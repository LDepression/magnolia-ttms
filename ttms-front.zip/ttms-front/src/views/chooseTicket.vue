<template>
  <div>
    <div class="detail">
          <h3 class="labelname">{{$route.query.movieInfo.name}}</h3>
          <hr/>
        <div>
          <div class="viewing">
            <span>观影时间：</span>
            <div @click="handletime" :class="{time:true,isSelected:currentTime==timelabel[0]}">{{timelabel[0]}}</div>
            <div @click="handletime" :class="{time:true,isSelected:currentTime==timelabel[1]}">{{timelabel[1]}}</div>
            <div @click="handletime" :class="{time:true,isSelected:currentTime==timelabel[2]}">{{timelabel[2]}}</div>
          </div>
        </div>
        <br>
        <br>
        <el-table
        :data="tableData"
        stripe
        style="width: 100%">
        <el-table-column
          prop="start_at"
          label="放映时间"
          width="180">
        </el-table-column>
        <el-table-column
          prop="version"
          label="语言版本"
          width="180">
        </el-table-column>
        <el-table-column
          prop="cinemaname"
          label="放映厅">
        </el-table-column>
        <el-table-column
          prop="price"
          label="售价（元）">
        </el-table-column>
        <el-table-column
          label="选座购票">
          <template slot-scope="scope">
          <el-button
          size="small "
          type="primary" round
          @click="chooseSeat(scope.$index)">选座购票</el-button>
        </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import { reactive, onMounted } from 'vue';
// import request from '../api/index';
import { onBeforeRouteLeave } from 'vue-router'
import Cookies from 'js-cookie'

export default {
  setup(props, { router }) {
    const tableData = reactive([]);
    const currentTime = ref('今天');
    const timelabel = reactive(['今天','明天','后天'])
    const period = reactive({
      start:'',
      end:''
    })
    const handleTime = (e) => {
      currentTime = e.target.innerHTML;
      switch (currentTime) {
        case '今天':
          period.start = new Date().setHours(0, 0, 0, 0);
          period.end = new Date().setHours(0, 0, 0, 0) + 24 * 60 * 60 * 1000;
          break;
        case '明天':
          period.start = new Date().setHours(0, 0, 0, 0) + 24 * 60 * 60 * 1000;
          period.end = new Date().setHours(0, 0, 0, 0) + 2 * 24 * 60 * 60 * 1000;
          break;
        case '后天':
          period.start = new Date().setHours(0, 0, 0, 0) + 2 * 24 * 60 * 60 * 1000;
          period.end = new Date().setHours(0, 0, 0, 0) + 3 * 24 * 60 * 60 * 1000;
          break;
      }
      // request
      //   .getPlanlist({
      //     movie_id: props.route.query.movie_id,
      //     start_time: new Date(state.period.start).toISOString().slice(0, 10),
      //     end_time: new Date(state.period.end).toISOString().slice(0, 10),
      //   })
      //   .then(
      //     (res) => {
      //       for (let i of res.data.data.list) {
      //         i.start_at = i.start_at.slice(11, 16);
      //       }
      //       state.tableData = res.data.data.list;
      //     },
      //     (err) => {
      //       console.log(err);
      //     }
      //   );
    };

    const chooseSeat = (x) => {
      let token = Cookies.get('AccessToken');
      if (token) {
        router.push({
          name: 'chooseSeat',
          query: { ticket: JSON.stringify(state.tableData[x]), movieInfo: JSON.stringify(props.route.query.movieInfo) },
        });
      } else {
        router.push({ path: '/login' });
      }
    };

    onMounted(() => {
      period.start = new Date().setHours(0, 0, 0, 0);
      period.end = new Date().setHours(0, 0, 0, 0) + 24 * 60 * 60 * 1000;
      // request
      //   .getPlanlist({
      //     movie_id: props.route.query.movie_id,
      //     start_time: new Date(state.period.start).toISOString().slice(0, 10),
      //     end_time: new Date(state.period.end).toISOString().slice(0, 10),
      //   })
      //   .then(
      //     (res) => {
      //       for (let i of res.data.data.list) {
      //         i.start_at = i.start_at.slice(11, 16);
      //       }
      //       state.tableData = res.data.data.list;
      //     },
      //     (err) => {
      //       console.log(err);
      //     }
      //   );
    });

    onBeforeRouteLeave((to, from, next) => {
      let token = Cookies.get('AccessToken');
      if (to.path == '/chooseSeat') {
        if (token) {
          next();
        } else {
          router.push({ path: '/login' });
        }
      }
      next();
    });

    return {tableData, 
   currentTime ,
    timelabel ,
     period, handleTime, chooseSeat };
  },
};
</script>

<style scoped>
.time {
  border-radius:14px;
  padding: 3px 9px;
  display: inline-block;
  margin-left: 12px;
  cursor: pointer;
}
.isSelected{
  background-color: #75c4ff;
  color: #fff;
}
.labelname::before{
    content: "";
    display: inline-block;
    width: 4px;
    height: 18px;
    margin-right: 6px;
    background-color: #11a8cd;
}
.detail{
    width:1000px;
    margin:50px auto;
    padding:10px;
}
</style>