<script setup>
import { onMounted, reactive, ref } from "vue";
import { findUser } from "../../../apis/user";
import {getMovieDetail,deleteMovie} from '../../../apis/movie'
const UserName = ref("");
const tableData = reactive({
  data:[
  
  {
    name: "妇联",
    area: "美国",
    duration: "男",
    action: "我是傻逼",
  },
  {
    name: "妇联",
    area: "美国",
    duration: "男",
    action: "我是傻逼",
  },
  {
    name: "妇联",
    area: "美国",
    duration: "男",
    action: "我是傻逼",
  },
  {
    name: "妇联",
    area: "美国",
    duration: "男",
    action: "我是傻逼",
  },
]
});
const getMovie = async () => {
  // let res = await getMovieDetail()
}
// const delete = async (movie_id) => {
//   let res = await deleteMovie(movie_id)
// }
const user = reactive({})

  // tableData.data = res.data.data


</script>
<template>
  <div class="search">
   电影信息
   <el-button class="btn" type="primary" >添加电影</el-button>

  </div>
  <div class="bigTable">
    <div class="table">
      <el-table :data="tableData.data" border style="width: 100%">
        <el-table-column prop="name" label="电影名称" width="168" />
        <el-table-column prop="area" label="电影地区" width="168">
        </el-table-column>
        <el-table-column prop="duration" label="上映时间" width="168" />
        <el-table-column prop="action" label="操作" width="168">
          <el-button class="btn" type="primary" >修改信息</el-button>
          <el-button class="btn" type="danger" >删除电影</el-button>
        </el-table-column>
      </el-table>
    </div>
  </div>

  <el-pagination
    :page-size="4"
    :pager-count="5"
    layout="prev, pager, next"
    :total="tableData.data.length"
    class="pagination"
  />
</template>
<style lang="css" scoped>
.pagination{
  margin-left: 400px;
  margin-top: 50px;
}
.search {
  /* position: relative;
  left: -68px; */
}
.btn {
  margin-left: 30px;
  margin-top: 10px;
}
.example-pagination-block{
  position: relative;
  left: 300px;
}
.example-pagination-block + .example-pagination-block {
  margin-top: 10px;
}
.example-pagination-block .example-demonstration {
  margin-bottom: 16px;
}
.table {
  margin-top: 30px;
}
.bigTable {
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>