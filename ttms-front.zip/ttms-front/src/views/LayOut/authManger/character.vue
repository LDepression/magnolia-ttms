<script setup>
import {onBeforeUnmount,computed, onMounted, onUnmounted, onUpdated, reactive,toRefs, watchEffect} from 'vue'
import {useStore} from "vuex";
import emitter from '../../../mitt/mitt';
const store = useStore()
const tableData = reactive({
  data:[
  
  
]
});
tableData.data = computed(()=> store.state.userList)
watchEffect(()=>{
  console.log(store.state.userList);
  console.log(store.state.movieID);
  // tableData.data = store.state.userList
})
onMounted(()=>{
  console.log();
  // tableData.data = store.state.userList
})


</script>
<template>
  <div class="board">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>权限管理</el-breadcrumb-item>
        <el-breadcrumb-item>角色信息管理</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <el-button type="primary" >添加角色</el-button>
    <el-button type="danger" >批量删除</el-button>
    <div class="bigTable">
    <div class="table">
    <el-table :data="tableData.data" border style="width: 100%">
        <el-table-column prop="username" label="角色用户名" width="168" />
        <el-table-column prop="avatar" label="角色名称" width="168">
        </el-table-column>
        <el-table-column prop="gender" label="角色描述" width="168" />
        <el-table-column prop="signature" label="操作" width="168">
          <el-button class="btn" type="primary">修改信息</el-button>
          <el-button class="btn" type="danger">删除用户</el-button>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<style>
.table {
  margin-top: 30px;
}
.bigTable {
  display: flex;
  justify-content: center;
  align-items: center;
}
.btn{
  position: relative;
  left: 10px;
}
</style>