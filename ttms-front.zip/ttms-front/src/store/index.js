
import { createStore,createLogger } from 'vuex'
 
export default createStore({
  state: {
    movieID:'3',
    userList:[]
  },
  // getters: {
  //   getUserList(state){
  //     return state.userList
  //   }
  // },
  mutations: {
    getMovieId(state,movieID){
      state.movieID = movieID
    },
    setUserList(state,list){
      state.userList = list
    }
  },
  actions: {
    
  },
  modules: {
  }
})